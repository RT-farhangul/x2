DROP TABLE x2_rec_new_module;
/*&*/
DELETE FROM x2_modules WHERE `name`='rec_new_module';
/*&*/
DELETE FROM x2_fields WHERE `modelName`='Rec_new_module';